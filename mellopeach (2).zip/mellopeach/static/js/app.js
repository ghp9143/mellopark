$(document).ready(function() {
    console.log("start");
})